<section class="panel">
    <h2>Dashboard</h2>
    <p>Selamat datang di aplikasi pengelolaan data barang yang disusun menggunakan konsep PHP Modular.</p>
    <div class="dashboard-actions">
        <a class="button" href="index.php?page=barang/list">Lihat Data Barang</a>
        <a class="button button-secondary" href="index.php?page=barang/add">Tambah Barang</a>
    </div>
    <h3>Function Helper</h3>
    <p>Contoh formatRupiah(150000): <strong><?= e(formatRupiah(150000)) ?></strong></p>
    <p>Contoh hitungDiskon(200000, 10): <strong><?= e(formatRupiah(hitungDiskon(200000, 10))) ?></strong></p>
</section>
