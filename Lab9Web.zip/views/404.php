<section class="panel empty-state">
    <h2>404 - Halaman tidak ditemukan</h2>
    <p>Halaman yang diminta tidak tersedia.</p>
    <a class="button" href="index.php">Kembali ke Dashboard</a>
</section>
