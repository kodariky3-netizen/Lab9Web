<?php
$pageAktif = $_GET['page'] ?? 'dashboard';
$titles = ['dashboard' => 'Dashboard', 'barang/list' => 'Data Barang', 'barang/add' => 'Tambah Barang', 'barang/edit' => 'Ubah Barang'];
$judulHalaman = $titles[$pageAktif] ?? 'Lab9Web';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($judulHalaman) ?> - Lab9Web</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">
    <header class="site-header">
        <div><h1>Lab9Web</h1><p>Aplikasi Data Barang • PHP Modular</p></div>
    </header>
    <nav class="navigation">
        <a class="<?= $pageAktif === 'dashboard' ? 'active' : '' ?>" href="index.php">Dashboard</a>
        <a class="<?= str_starts_with($pageAktif, 'barang/') ? 'active' : '' ?>" href="index.php?page=barang/list">Data Barang</a>
    </nav>
    <main class="main-content">
