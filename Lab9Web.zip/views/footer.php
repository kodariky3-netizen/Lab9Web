    </main>
    <footer class="site-footer">&copy; <?= date('Y') ?> Praktikum Pemrograman Web - PHP Modular</footer>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
