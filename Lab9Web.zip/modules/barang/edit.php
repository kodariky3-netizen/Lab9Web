<?php
require_once __DIR__ . '/../../config/database.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(404); require __DIR__ . '/../../views/404.php'; return; }
$stmt = mysqli_prepare($conn, 'SELECT * FROM data_barang WHERE id_barang = ?');
mysqli_stmt_bind_param($stmt, 'i', $id); mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$data) { http_response_code(404); require __DIR__ . '/../../views/404.php'; return; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? ''); $kategori = trim($_POST['kategori'] ?? '');
    $harga_jual = (float)($_POST['harga_jual'] ?? 0); $harga_beli = (float)($_POST['harga_beli'] ?? 0); $stok = (int)($_POST['stok'] ?? 0);
    if ($nama === '' || $kategori === '') $errors[] = 'Nama dan kategori wajib diisi.';
    if ($harga_jual < 0 || $harga_beli < 0 || $stok < 0) $errors[] = 'Harga dan stok tidak boleh negatif.';
    $gambarBaru = uploadGambar($_FILES['file_gambar'] ?? []);
    $gambar = $gambarBaru ?: $data['gambar'];
    if (!$errors) {
        $update = mysqli_prepare($conn, 'UPDATE data_barang SET nama=?, kategori=?, harga_jual=?, harga_beli=?, stok=?, gambar=? WHERE id_barang=?');
        mysqli_stmt_bind_param($update, 'ssddisi', $nama, $kategori, $harga_jual, $harga_beli, $stok, $gambar, $id);
        if (mysqli_stmt_execute($update)) redirect('index.php?page=barang/list');
        $errors[] = 'Data gagal diperbarui.';
    }
    $data = array_merge($data, compact('nama','kategori','harga_jual','harga_beli','stok','gambar'));
}
?>
<section class="panel form-panel"><h2>Ubah Barang</h2>
<?php foreach ($errors as $error): ?><p class="alert error"><?= e($error) ?></p><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <label>Nama Barang<input type="text" name="nama" value="<?= e($data['nama']) ?>" required></label>
    <label>Kategori<select name="kategori" required><?php foreach (['Komputer','Elektronik','Hand Phone'] as $kategori): ?><option value="<?= e($kategori) ?>" <?= $data['kategori'] === $kategori ? 'selected' : '' ?>><?= e($kategori) ?></option><?php endforeach; ?></select></label>
    <div class="form-grid"><label>Harga Jual<input type="number" name="harga_jual" min="0" value="<?= e($data['harga_jual']) ?>" required></label><label>Harga Beli<input type="number" name="harga_beli" min="0" value="<?= e($data['harga_beli']) ?>" required></label><label>Stok<input type="number" name="stok" min="0" value="<?= e($data['stok']) ?>" required></label></div>
    <?php if (!empty($data['gambar'])): ?><p>Gambar saat ini: <img class="product-thumb" src="<?= e($data['gambar']) ?>" alt="Gambar barang"></p><?php endif; ?>
    <label>Ganti Gambar (opsional)<input type="file" name="file_gambar" accept="image/jpeg,image/png,image/gif,image/webp"></label>
    <div class="form-actions"><button class="button" type="submit">Simpan Perubahan</button><a class="button button-secondary" href="index.php?page=barang/list">Kembali</a></div>
</form></section>
