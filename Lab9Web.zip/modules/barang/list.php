<?php
require_once __DIR__ . '/../../config/database.php';
$result = mysqli_query($conn, 'SELECT * FROM data_barang ORDER BY id_barang DESC');
?>
<section class="panel">
    <div class="section-heading"><div><h2>Data Barang</h2><p>Daftar barang yang tersimpan di database.</p></div><a class="button" href="index.php?page=barang/add">+ Tambah Barang</a></div>
    <div class="table-wrap"><table>
        <thead><tr><th>Gambar</th><th>Nama Barang</th><th>Kategori</th><th>Harga Beli</th><th>Harga Jual</th><th>Stok</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php if (!empty($row['gambar'])): ?><img class="product-thumb" src="<?= e($row['gambar']) ?>" alt="Gambar barang"><?php else: ?><span class="muted">Tidak ada</span><?php endif; ?></td>
                <td><?= e($row['nama']) ?></td><td><?= e($row['kategori']) ?></td>
                <td><?= e(formatRupiah($row['harga_beli'])) ?></td><td><?= e(formatRupiah($row['harga_jual'])) ?></td><td><?= e($row['stok']) ?></td>
                <td class="actions"><a href="index.php?page=barang/edit&id=<?= (int)$row['id_barang'] ?>">Ubah</a>
                    <form method="post" action="index.php?page=barang/delete" onsubmit="return confirm('Yakin ingin menghapus barang ini?')"><input type="hidden" name="id" value="<?= (int)$row['id_barang'] ?>"><button class="link-danger" type="submit">Hapus</button></form>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?><tr><td colspan="7" class="empty-cell">Belum ada data barang.</td></tr><?php endif; ?>
        </tbody>
    </table></div>
</section>
