<?php
require_once __DIR__ . '/../../config/database.php';
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $harga_jual = (float)($_POST['harga_jual'] ?? 0);
    $harga_beli = (float)($_POST['harga_beli'] ?? 0);
    $stok = (int)($_POST['stok'] ?? 0);
    if ($nama === '' || $kategori === '') $errors[] = 'Nama dan kategori wajib diisi.';
    if ($harga_jual < 0 || $harga_beli < 0 || $stok < 0) $errors[] = 'Harga dan stok tidak boleh negatif.';
    $gambar = uploadGambar($_FILES['file_gambar'] ?? []);
    if (!$errors) {
        $sql = 'INSERT INTO data_barang (nama, kategori, harga_jual, harga_beli, stok, gambar) VALUES (?, ?, ?, ?, ?, ?)';
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'ssddis', $nama, $kategori, $harga_jual, $harga_beli, $stok, $gambar);
        if (mysqli_stmt_execute($stmt)) redirect('index.php?page=barang/list');
        $errors[] = 'Data gagal disimpan.';
    }
}
?>
<section class="panel form-panel"><h2>Tambah Barang</h2>
<?php foreach ($errors as $error): ?><p class="alert error"><?= e($error) ?></p><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
    <label>Nama Barang<input type="text" name="nama" value="<?= e($_POST['nama'] ?? '') ?>" required></label>
    <label>Kategori<select name="kategori" required><option value="">Pilih kategori</option><?php foreach (['Komputer','Elektronik','Hand Phone'] as $kategori): ?><option value="<?= e($kategori) ?>" <?= (($_POST['kategori'] ?? '') === $kategori) ? 'selected' : '' ?>><?= e($kategori) ?></option><?php endforeach; ?></select></label>
    <div class="form-grid"><label>Harga Jual<input type="number" name="harga_jual" min="0" value="<?= e($_POST['harga_jual'] ?? '') ?>" required></label><label>Harga Beli<input type="number" name="harga_beli" min="0" value="<?= e($_POST['harga_beli'] ?? '') ?>" required></label><label>Stok<input type="number" name="stok" min="0" value="<?= e($_POST['stok'] ?? '') ?>" required></label></div>
    <label>Gambar Barang<input type="file" name="file_gambar" accept="image/jpeg,image/png,image/gif,image/webp"></label>
    <div class="form-actions"><button class="button" type="submit">Simpan</button><a class="button button-secondary" href="index.php?page=barang/list">Kembali</a></div>
</form></section>
