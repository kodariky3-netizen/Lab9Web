<?php
function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function formatRupiah($angka): string {
    return 'Rp ' . number_format((float)$angka, 0, ',', '.');
}

function hitungDiskon(float $harga, float $persen = 10): float {
    return $harga * ($persen / 100);
}

function validasiEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function ringkasTeks(string $teks, int $batas = 50): string {
    $teks = trim($teks);
    if (mb_strlen($teks) <= $batas) return $teks;
    return mb_substr($teks, 0, $batas) . '...';
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

function uploadGambar(array $file): ?string {
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) return null;

    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext]) || !is_uploaded_file($file['tmp_name'])) return null;
    $mime = mime_content_type($file['tmp_name']);
    if ($mime !== $allowed[$ext]) return null;

    $nama = bin2hex(random_bytes(8)) . '.' . $ext;
    $folder = dirname(__DIR__) . '/gambar/';
    if (!is_dir($folder)) mkdir($folder, 0775, true);
    if (!move_uploaded_file($file['tmp_name'], $folder . $nama)) return null;
    return 'gambar/' . $nama;
}
